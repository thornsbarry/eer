<?php

    /*
     * Подключаем файл для получения соединения к базе данных (PhpMyAdmin, MySQL)
     */

    require_once 'vendor/connect.php';

    /*
     * Получаем ID продукта из адресной строки - /product.php?id=1
     */

    $product_id = $_GET['id'];

    /*
     * Делаем выборку строки с полученным ID выше
     */

    $product = mysqli_query($connect, "SELECT * FROM `products` WHERE `id` = '$product_id'");

    /*
     * Преобразовывем полученные данные в нормальный массив
     * Используя функцию mysqli_fetch_assoc массив будет иметь ключи равные названиям столбцов в таблице
     */

    $product = mysqli_fetch_assoc($product);

    /*
     * Делаем выборку всех строк комментариев с полученным ID продукта выше
     */

    $comments = mysqli_query($connect, "SELECT * FROM `comments` WHERE `product_id` = '$product_id'");

    /*
     * Преобразовывем полученные данные в нормальный массив
     */

    $comments = mysqli_fetch_all($comments);
?>

<!doctype html>
<html lang="en">
<head>
    <title>Просмотр товара</title>
</head>
<style>
    .comm {
        box-sizing: border-box;
        font-family: Tahoma;

    }

    .comb {
        font-family: Tahoma;
    padding-top: 10px;
    text-align: center;
    border-radius: 12px;
    background: #f0f0f0;
    color: black;
    border: #F0F0F0;
    width: 130px;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
    align-items: center;
    }
    </style>
<body>
<form class="comm">
    <h4>Цена: <?= $product['price'] ?></h4>
    <p>Наименование: <?= $product['description'] ?></p>
</form>
    <hr>

    <h3 style="font-family: Tahoma;">Добавить комментарий</h3>
    <form action="vendor/create_comment.php" method="post">
        <input type="hidden" name="id" value="<?= $product['id'] ?>">
        <textarea name="body"></textarea> <br><br>
        <button class="comb" type="submit">Добавить</button>
    </form>

    <hr>

    <h3 style="font-family: Tahoma;">Комментария</h3>
    <ul>
        <?php

            /*
             * Перебираем массив с комментариями и выводим
             */

            foreach ($comments as $comment) {
            ?>
                <li><?= $comment[2] ?></li>
            <?php
            }
        ?>
    </ul>
</body>
</html>