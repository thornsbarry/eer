<?php

    /*
     * Подключаем файл для получения соединения к базе данных (PhpMyAdmin, MySQL)
     */

    require_once 'vendor/connect.php';

    /*
     * Получаем ID продукта из адресной строки - /product.php?id=1
     */

    $product_id = $_GET['id'];

    /*
     * Делаем выборку строки с полученным ID выше
     */

    $product = mysqli_query($connect, "SELECT * FROM `products` WHERE `id` = '$product_id'");

    /*
     * Преобразовывем полученные данные в нормальный массив
     * Используя функцию mysqli_fetch_assoc массив будет иметь ключи равные названиям столбцов в таблице
     */

    $product = mysqli_fetch_assoc($product);
?>

<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Редактирование продукта</title>
</head>
<style>
        .comb {
        font-family: Tahoma;
    padding-top: 10px;
    text-align: center;
    border-radius: 12px;
    background: #f0f0f0;
    color: black;
    border: #F0F0F0;
    width: 130px;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
    align-items: center;
    }
    </style>
<body>
    <h3 style="font-family: Tahoma;">Редактирование</h3>
    <form action="vendor/update.php" method="post">
        <input type="hidden" name="id" value="<?= $product['id'] ?>">

        <input type="text" name="title" value="<?= $product['title'] ?>">
        <p style="font-family: Tahoma;">Наименование</p>
        <textarea name="description"><?= $product['description'] ?></textarea>
        <p style="font-family: Tahoma;">Цена</p>
        <input type="number" name="price" value="<?= $product['price'] ?>"> <br> <br>
        <button class="comb" type="submit">Редактировать</button>
    </form>
</body>
</html>