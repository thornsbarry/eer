<?php

/*
 * Подключаем файл для получения соединения к базе данных (PhpMyAdmin, MySQL)
 */

require_once 'vendor/connect.php';

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Инвентаризация</title>
</head>
<style>
    
    th, td {
        padding: 10px;
        font-family: Tahoma;
    }

    th {
        background: #9ACFFF;
        border-radius: 9px;
        color: #fff;
    }

    td {
        background: #D9D9D9;
        border-radius: 4px;
    }
    <style>
    /* Оформление панели */
#side-checkbox {
    display: none;
}
.side-panel {
    position: fixed;
    z-index: 999999;
    top: 0;
    left: -360px;
    background: #9ACFFF;
    transition: all 0.5s;   
    width: 320px;
    height: 100vh;
    box-shadow: 10px 0 20px rgba(0,0,0,0.4);
    color: #FFF;
    padding: 40px 20px;
    border-radius: 12px;
}
.side-title {
    font-size: 20px;
    padding-bottom: 10px;
    margin-bottom: 20px;
    border-bottom: 2px solid #BFE2FF;
}
/* Оформление кнопки на странице */
.side-button-1-wr {
    text-align: center; /* Контейнер для кнопки, чтобы было удобнее ее разместить */
}
.side-button-1 {
    display: inline-block;
}
.side-button-1 .side-b {
    font-family: Tahoma;
    margin: 10px;
    text-decoration: none;
    position: relative;
    font-size: 20px;
    line-height: 20px;
    padding: 12px 30px;
    color: #FFF;
    font-weight: bold;
    text-transform: uppercase; 

    background: #9ACFFF;
    cursor: pointer; 
    border-radius: 12px;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
}
.side-button-1 .side-b:hover,
.side-button-1 .side-b:active,
.side-button-1 .side-b:focus {
    color: #FFF;
}
.side-button-1 .side-b:after,
.side-button-1 .side-b:before {
    position: absolute;
    height: 4px;
    left: 50%;
    bottom: -6px;
    content: "";
    transition: all 280ms ease-in-out;
    width: 0;

}
.side-button-1 .side-open:after,
.side-button-1 .side-open:before {
    background: green;
}
.side-button-1 .side-close:after,
.side-button-1 .side-close:before {
    background: red;
}
.side-button-1 .side-b:before {
    top: -6px;
}
.side-button-1 .side-b:hover:after,
.side-button-1 .side-b:hover:before {
    width: 100%;
    left: 0;
}
/* Переключатели кнопки 1 */
.side-button-1 .side-close {
    display: none;
}
#side-checkbox:checked + .side-panel + .side-button-1-wr .side-button-1 .side-open {
    display: none;
}
#side-checkbox:checked + .side-panel + .side-button-1-wr .side-button-1 .side-close {
    display: block;
}
#side-checkbox:checked + .side-panel {
    left: 0;
}
/* Оформление кнопки на панеле */
.side-button-2 {
    font-family: Tahoma;
    font-size: 30px;
    border-radius: 20px;
    position: absolute;
    z-index: 1;
    top: 8px;
    right: 8px;
    cursor: pointer;
    transform: rotate(45deg);
    color: #BFE2FF;    
    transition: all 280ms ease-in-out;    
}
.side-button-2:hover {
    transform: rotate(45deg) scale(1.1);    
    color: #FFF;

}
.bt1 {
    font-family: Tahoma;
    padding-top: 10px;
    text-align: center;
    border-radius: 12px;
    background: #f0f0f0;
    color: black;
    border: #F0F0F0;
    width: 130px;
    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.25);
}
.bt2 {
    font-family: Tahoma;

}
.bt3 {

    border-radius: 12px;
    border: red;

}

    </style>
<body>
    

</div>
</div>
<body>
<a class="button" href="profile.php" style="  display: inline-block;
  background: #2196f3;
  color: #fff;
  padding: 12px;
  border-radius: 6px;
  text-decoration: none;
  font-family: Tahoma;
  font-size: 15px;
  line-height: 1;
  font-weight: 100;">Перейти в профиль</a>
    <table>
        <tr>

            <th>Наименование</th>
            <span></span>
            <th>Цена</th>

        </tr>

        <?php

            /*
             * Делаем выборку всех строк из таблицы "products"
             */

            $products = mysqli_query($connect, "SELECT * FROM `products`");

            /*
             * Преобразовываем полученные данные в нормальный массив
             */

            $products = mysqli_fetch_all($products);

            /*
             * Перебираем массив и рендерим HTML с данными из массива
             * Ключ 2 - price
             * Ключ 3 - description
             */

            foreach ($products as $product) {
                ?>
                    <tr>

                        <td><?= $product[3] ?></td>
                        <td><?= $product[2] ?>₽</td>

                    </tr>
                <?php
            }
        ?>
    </table>


</body>
</html>
