<?php
session_start();
if (!$_SESSION['user']) {
    header('Location: profile.php');
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Профиль</title>
    <link rel="stylesheet" href="assets/css/main.css">
</head>
<body>

    <!-- Профиль -->
<form class="frame">
    <form>
    <img src="<?= $_SESSION['user']['avatar'] ?>" width="150" alt="" style="
    padding-top: 10px;
    padding-left: 10px;">
        <h2 style="margin: 10px 0; padding-left: 10px;"><?= $_SESSION['user']['full_name'] ?></h2>
        <a href="index.php" class="btn" style="padding-left: 10px;">Инвентаризация</a>
        <a href="admindex.php" class="btn" style="padding-left: 10px;">Панель разработчика</a>
        <a href="vendor/logout.php" class="logout btn" style="padding-left: 10px;">Выход</a>
    </form>
</from>
</body>
</html>